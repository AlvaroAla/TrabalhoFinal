<?php
class Conexao
{
    public $conexao;

    function __construct()
    {
        if (!isset($this->conexao)) {
            try {
                $this->conexao = new PDO('mysql:host=localhost;dbname=dcs', 'root', '');
            } catch (PDOException $e) {
                echo 'Error: ' . $e->getMessage();
            }
        }
    }

    function fecharConexao()
    {
        if (isset($this->conexao)) {
            $this->conexao = null;
        }
    }
}
